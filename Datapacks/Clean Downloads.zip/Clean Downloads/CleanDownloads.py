import os
import shutil
import getpass

# Encontrar nombre de usuador
User = getpass.getuser().replace(" ",'')

# Establecer la direction dela carpeta de descargas
path = f"C:\\Users\\{User}\\Downloads\\"

# Borrar todo lo que tiene la carpeta de descargas
for file_name in os.listdir(path):
    try:
        os.remove(path + file_name)
        print(f"Se ha borrado {file_name}")
    except PermissionError:
        shutil.rmtree(path + file_name)
        print(f"Se ha borrado {file_name}")

# Mensage final
print("Se ha completado la limpieza :)")

# Paraque se pueda ver todo
Done = input('')
